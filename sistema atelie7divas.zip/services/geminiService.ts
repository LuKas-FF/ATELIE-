
import { GoogleGenAI } from "@google/genai";
import { Product, Transaction } from "../types";

// Fix: Always use the named parameter and obtain the API key exclusively from process.env.API_KEY.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeInventory = async (products: Product[], transactions: Transaction[]) => {
  const prompt = `
    Analise os seguintes dados de estoque e forneça 3 insights críticos para a gestão.
    Considere: Itens abaixo do estoque mínimo, produtos com maior lucratividade, e giro de estoque.
    
    Produtos: ${JSON.stringify(products.map(p => ({ sku: p.sku, name: p.name, current: p.currentStock, min: p.minStock, cost: p.costPrice, sale: p.salePrice })))}
    Transações Recentes: ${JSON.stringify(transactions.slice(-10))}
    
    Responda em Português do Brasil de forma executiva e direta.
  `;

  try {
    // Fix: Use ai.models.generateContent with model name and prompt in a single call.
    // Basic text tasks like summarization and simple Q&A should use gemini-3-flash-preview.
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        temperature: 0.7,
        topP: 0.8,
      }
    });
    // Fix: The GenerateContentResponse features a .text property, not a method.
    return response.text;
  } catch (error) {
    console.error("Gemini analysis error:", error);
    return "Não foi possível realizar a análise no momento.";
  }
};
