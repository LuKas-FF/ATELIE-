
import { User, UserRole, Product, Transaction, AppConfig, Store, RawMaterialEntry } from '../types';

export const mockStores: Store[] = [
  { id: 's1', name: 'Ateliê Matriz - Jardins', status: 'ATIVA' },
  { id: 's2', name: 'Showroom Dourado', status: 'ATIVA' },
  { id: 's3', name: 'Loja Online Office', status: 'ATIVA' }
];

export const mockConfig: AppConfig = {
  companyName: "ATELIÊ 7 DIVAS",
  logoText: "7D",
  primaryColor: "#B91C1C", 
  accentColor: "#D4AF37",  
  stores: mockStores
};

export const mockUsers: User[] = [
  { id: '1', name: 'Administradora Geral', email: 'admin@atelie.com', password: 'admin', role: UserRole.ADMIN, status: 'ATIVO', avatar: 'https://i.pravatar.cc/150?u=a1' },
  { id: '2', name: 'Gerente Financeira', email: 'financeiro@atelie.com', password: '123', role: UserRole.FINANCEIRO, status: 'ATIVO', avatar: 'https://i.pravatar.cc/150?u=f1' },
  { id: '3', name: 'Equipe Operacional', email: 'op@atelie.com', password: '123', role: UserRole.ESTOQUE_EXPEDICAO, status: 'ATIVO', avatar: 'https://i.pravatar.cc/150?u=e1' },
  { id: '4', name: 'Recebimento de Tecidos', email: 'tecidos@atelie.com', password: '123', role: UserRole.ENTRADA_INSUMOS, status: 'ATIVO', avatar: 'https://i.pravatar.cc/150?u=v1' }
];

export const mockProducts: Product[] = [
  { id: 'p1', sku: 'VEST-RED-G', name: 'Vestido Gala Red Velvet', category: 'Vestidos', unit: 'un', costPrice: 450, salePrice: 1350, minStock: 2, currentStock: 12 },
  { id: 'p2', sku: 'TIARA-GOLD', name: 'Tiara Imperial Sete Divas', category: 'Acessórios', unit: 'un', costPrice: 95, salePrice: 320, minStock: 5, currentStock: 25 },
  { id: 'p3', sku: 'VEST-WHITE-M', name: 'Vestido White Diamond', category: 'Vestidos', unit: 'un', costPrice: 600, salePrice: 1800, minStock: 1, currentStock: 3 }
];

export const mockRawMaterials: RawMaterialEntry[] = [
  { id: 'rm1', item: 'Tecido Velvet Premium', quantity: 50, unit: 'metros', value: 2500, supplier: 'Têxtil Luxury', date: '2023-10-01', userId: '2' },
  { id: 'rm2', item: 'Pedrarias de Cristal', quantity: 1000, unit: 'unidades', value: 1200, supplier: 'Brilho & Cia', date: '2023-10-05', userId: '2' }
];

export const mockTransactions: Transaction[] = [];
