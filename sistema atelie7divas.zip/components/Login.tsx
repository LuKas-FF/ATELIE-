
import React, { useState, useEffect } from 'react';
import { AppConfig } from '../types';

interface LoginProps {
  onLogin: (email: string, pass: string) => void;
  error: string;
  config: AppConfig;
}

const Login: React.FC<LoginProps> = ({ onLogin, error, config }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [localError, setLocalError] = useState('');

  useEffect(() => {
    setLocalError(error);
  }, [error]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError('');
    setLoading(true);
    setTimeout(() => {
      onLogin(email, password);
      setLoading(false);
    }, 800);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#050505] px-4 py-10 font-['Inter'] relative overflow-hidden">
      {/* Background Decorativo */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] right-[-10%] md:w-[50%] md:h-[50%] w-[80%] h-[40%] bg-[#B91C1C]/10 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-10%] left-[-10%] md:w-[50%] md:h-[50%] w-[80%] h-[40%] bg-[#D4AF37]/5 rounded-full blur-[120px]"></div>
      </div>

      <div className="max-w-md w-full relative z-10 animate-in fade-in zoom-in duration-700">
        <div className="bg-[#111] border border-white/5 p-8 md:p-12 rounded-[2.5rem] shadow-2xl">
          <div className="flex flex-col items-center mb-10">
            {config.logoUrl ? (
              <img src={config.logoUrl} alt="Logo" className="w-20 h-20 md:w-24 md:h-24 object-contain mb-6 drop-shadow-[0_0_15px_rgba(212,175,55,0.3)]" />
            ) : (
              <div className="w-16 h-16 md:w-20 md:h-20 bg-[#D4AF37] rounded-full flex items-center justify-center font-black text-2xl md:text-3xl text-black border-4 border-white shadow-[0_0_30px_rgba(212,175,55,0.3)] mb-6">
                {config.logoText}
              </div>
            )}
            <h1 className="text-xl md:text-2xl font-black text-white tracking-[0.2em] text-center uppercase leading-tight">{config.companyName}</h1>
            <p className="text-slate-500 text-[8px] font-bold uppercase tracking-[0.4em] mt-3">Controle de Acesso ERP</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="text-[9px] font-black text-[#D4AF37] uppercase tracking-[0.2em] block mb-2 ml-1">E-mail Corporativo</label>
              <input
                type="email" required autoComplete="email"
                className="w-full bg-black border border-white/10 text-white px-5 py-4 rounded-2xl focus:ring-2 focus:ring-[#B91C1C] outline-none transition-all placeholder:text-slate-800 font-medium text-sm"
                placeholder="admin@7divas.com"
                value={email}
                onChange={(e) => { setEmail(e.target.value); setLocalError(''); }}
              />
            </div>

            <div>
              <label className="text-[9px] font-black text-[#D4AF37] uppercase tracking-[0.2em] block mb-2 ml-1">Senha Privada</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"} 
                  required autoComplete="current-password"
                  className="w-full bg-black border border-white/10 text-white px-5 py-4 rounded-2xl focus:ring-2 focus:ring-[#B91C1C] outline-none transition-all placeholder:text-slate-800 text-sm"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setLocalError(''); }}
                />
                <button 
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-[#D4AF37] transition-colors p-2"
                  title={showPassword ? "Ocultar senha" : "Ver senha"}
                >
                  {showPassword ? (
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l18 18" /></svg>
                  ) : (
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                  )}
                </button>
              </div>
            </div>

            {localError && (
              <div className="bg-red-500/10 border border-red-500/30 text-red-500 text-[10px] font-black py-4 px-4 rounded-xl text-center uppercase tracking-widest animate-bounce">
                {localError}
              </div>
            )}

            <button
              type="submit" disabled={loading}
              className="w-full bg-[#B91C1C] text-white py-5 rounded-2xl font-black uppercase tracking-[0.2em] text-[10px] md:text-[11px] shadow-xl shadow-[#B91C1C]/20 hover:bg-red-700 transition-all flex items-center justify-center disabled:opacity-50 active:scale-95"
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Processando...
                </div>
              ) : "Entrar no Sistema"}
            </button>
          </form>

          <div className="mt-10 pt-8 border-t border-white/5">
             <p className="text-center text-slate-700 text-[8px] font-black uppercase tracking-widest leading-relaxed">
              Sistema de Alta Segurança Ativo<br/>
              Acesso Monitorado por IP e Auditoria
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
