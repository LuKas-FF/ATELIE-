
import React, { useState, useRef } from 'react';
import { Product, UserRole } from '../types';

interface InventoryTableProps {
  products: Product[];
  role: UserRole;
  onUpdateStock: (productId: string, delta: number, type: 'ENTRY' | 'EXIT') => void;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
  accentColor: string;
}

const InventoryTable: React.FC<InventoryTableProps> = ({ products, role, onUpdateStock, onEditProduct, onDeleteProduct, accentColor }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const filtered = products.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const isAdmin = role === UserRole.ADMIN;
  const canEntry = [UserRole.ADMIN, UserRole.ESTOQUE_EXPEDICAO].includes(role);
  const canExit = [UserRole.ADMIN, UserRole.ESTOQUE_EXPEDICAO].includes(role);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && editingProduct) {
      const base64 = await fileToBase64(file);
      setEditingProduct({ ...editingProduct, imageUrl: base64 });
    }
  };

  const openModal = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
    } else {
      setEditingProduct({
        sku: '', name: '', category: '', unit: 'un', costPrice: 0, salePrice: 0, minStock: 0, currentStock: 0, imageUrl: ''
      });
    }
    setShowModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingProduct) {
      onEditProduct(editingProduct as Product);
      setShowModal(false);
      setEditingProduct(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-[1.5rem] md:rounded-[3rem] shadow-xl border border-slate-100 overflow-hidden">
        <div className="p-6 md:p-12 border-b border-slate-50 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-center md:text-left">
            <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tighter uppercase">Gestão de Acervo</h2>
            <p className="text-slate-400 text-[10px] uppercase font-bold tracking-widest mt-1">Controle Digital de Peças</p>
          </div>
          <div className="flex flex-col md:flex-row gap-3 w-full md:w-auto">
            <div className="relative flex-1">
              <input
                type="text" placeholder="SKU ou Nome..."
                className="w-full pl-12 pr-6 py-4 border border-slate-100 bg-slate-50 rounded-2xl text-sm font-bold outline-none"
                value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
              />
              <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </div>
            {isAdmin && (
              <button onClick={() => openModal()} className="bg-black text-[#D4AF37] px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl">+ Adicionar</button>
            )}
          </div>
        </div>

        {/* VERSÃO DESKTOP (TABELA) */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50/50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
              <tr>
                <th className="px-10 py-6">Visual / Peça</th>
                <th className="px-10 py-6 text-right">Valor Venda</th>
                <th className="px-10 py-6 text-right">Estoque</th>
                <th className="px-10 py-6 text-center">Operações</th>
                {isAdmin && <th className="px-10 py-6 text-center">Gestão</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map(product => (
                <tr key={product.id} className="hover:bg-slate-50/50 transition-all group">
                  <td className="px-10 py-6">
                    <div className="flex items-center gap-6">
                      <div className="w-16 h-20 bg-black rounded-xl overflow-hidden shadow-md flex-shrink-0 flex items-center justify-center">
                        {product.imageUrl ? <img src={product.imageUrl} className="w-full h-full object-cover" /> : <span className="text-white font-black text-xl">7D</span>}
                      </div>
                      <div>
                        <p className="font-black text-slate-900 text-lg uppercase truncate max-w-[200px]">{product.name}</p>
                        <p className="text-[9px] font-bold text-[#D4AF37] uppercase tracking-widest mt-1">SKU: {product.sku}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-10 py-6 text-right">
                    <p className="text-xl font-black text-slate-900">R$ {product.salePrice.toLocaleString()}</p>
                  </td>
                  <td className="px-10 py-6 text-right">
                    <div className="flex flex-col items-end">
                      <span className={`text-2xl font-black ${product.currentStock <= product.minStock ? 'text-red-600' : 'text-slate-900'}`}>{product.currentStock}</span>
                      <span className={`text-[8px] font-black px-2 py-0.5 rounded uppercase ${product.currentStock <= product.minStock ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>{product.currentStock <= product.minStock ? 'REPOR' : 'OK'}</span>
                    </div>
                  </td>
                  <td className="px-10 py-6 text-center">
                    <div className="flex justify-center gap-2">
                      {canEntry && <button onClick={() => onUpdateStock(product.id, 1, 'ENTRY')} className="w-10 h-10 flex items-center justify-center bg-white border border-slate-100 text-green-600 rounded-xl hover:bg-green-600 hover:text-white transition-all shadow-sm font-black text-xl">+</button>}
                      {canExit && <button onClick={() => onUpdateStock(product.id, 1, 'EXIT')} className="w-10 h-10 flex items-center justify-center bg-white border border-slate-100 text-red-600 rounded-xl hover:bg-red-600 hover:text-white transition-all shadow-sm font-black text-xl">-</button>}
                    </div>
                  </td>
                  {isAdmin && (
                    <td className="px-10 py-6 text-center">
                       <button onClick={() => openModal(product)} className="p-2 text-slate-300 hover:text-[#D4AF37]"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" strokeWidth={2} /></svg></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* VERSÃO MOBILE (CARDS) */}
        <div className="lg:hidden p-4 space-y-4 bg-slate-50/30">
          {filtered.map(product => (
            <div key={product.id} className="bg-white p-5 rounded-[2rem] shadow-sm border border-slate-100 flex gap-5">
              <div className="w-24 h-32 bg-black rounded-2xl overflow-hidden flex-shrink-0 flex items-center justify-center shadow-lg">
                {product.imageUrl ? <img src={product.imageUrl} className="w-full h-full object-cover" /> : <span className="text-white font-black text-2xl">7D</span>}
              </div>
              <div className="flex-1 flex flex-col justify-between py-1">
                <div>
                  <h4 className="font-black text-slate-900 uppercase text-sm leading-tight mb-1">{product.name}</h4>
                  <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">SKU: {product.sku}</p>
                </div>
                <div className="flex justify-between items-end">
                   <div>
                     <p className="text-[8px] font-black text-slate-400 uppercase">Venda</p>
                     <p className="text-lg font-black text-slate-900 leading-none">R$ {product.salePrice.toFixed(0)}</p>
                   </div>
                   <div className="text-right">
                     <p className="text-[8px] font-black text-slate-400 uppercase">Estoque</p>
                     <p className={`text-xl font-black leading-none ${product.currentStock <= product.minStock ? 'text-red-600' : 'text-slate-900'}`}>{product.currentStock}</p>
                   </div>
                </div>
                <div className="flex gap-2 pt-2">
                   <button onClick={() => onUpdateStock(product.id, 1, 'ENTRY')} className="flex-1 bg-green-50 text-green-600 py-2 rounded-xl font-black text-lg">+</button>
                   <button onClick={() => onUpdateStock(product.id, 1, 'EXIT')} className="flex-1 bg-red-50 text-red-600 py-2 rounded-xl font-black text-lg">-</button>
                   {isAdmin && <button onClick={() => openModal(product)} className="px-4 bg-slate-50 text-slate-400 py-2 rounded-xl font-black">...</button>}
                </div>
              </div>
            </div>
          ))}
          {filtered.length === 0 && <p className="text-center py-10 text-slate-400 font-bold uppercase text-[10px]">Nenhuma peça encontrada.</p>}
        </div>
      </div>

      {/* MODAL RESPONSIVO */}
      {showModal && editingProduct && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <form onSubmit={handleSave} className="bg-white w-full max-w-2xl rounded-[2.5rem] md:rounded-[3.5rem] overflow-hidden shadow-2xl flex flex-col max-h-[95vh] animate-in zoom-in-95 duration-300">
            <div className="bg-black p-6 md:p-10 text-center"><h2 className="text-[#D4AF37] font-black uppercase tracking-[0.2em] text-sm md:text-xl">Edição de Peça</h2></div>
            <div className="p-6 md:p-10 space-y-4 md:space-y-6 overflow-y-auto custom-scrollbar">
              <div className="flex flex-col items-center gap-4 p-6 bg-slate-50 rounded-[2.5rem] border border-slate-100">
                <div className="w-32 h-44 md:w-44 md:h-60 bg-black rounded-2xl overflow-hidden shadow-xl border-4 border-white flex items-center justify-center">
                  {editingProduct.imageUrl ? <img src={editingProduct.imageUrl} className="w-full h-full object-cover" /> : <div className="text-[#D4AF37] font-black text-3xl">7D</div>}
                </div>
                <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="image/*" className="hidden" />
                <button type="button" onClick={() => fileInputRef.current?.click()} className="bg-black text-[#D4AF37] px-8 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-xl">Carregar Foto</button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div><label className="text-[9px] font-black text-slate-400 uppercase block mb-1">SKU</label><input required className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl text-xs md:text-sm font-bold outline-none" value={editingProduct.sku} onChange={e => setEditingProduct({...editingProduct, sku: e.target.value})} /></div>
                <div><label className="text-[9px] font-black text-slate-400 uppercase block mb-1">Categoria</label><input required className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl text-xs md:text-sm font-bold outline-none" value={editingProduct.category} onChange={e => setEditingProduct({...editingProduct, category: e.target.value})} /></div>
              </div>
              <div><label className="text-[9px] font-black text-slate-400 uppercase block mb-1">Nome Completo</label><input required className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl text-xs md:text-sm font-bold outline-none" value={editingProduct.name} onChange={e => setEditingProduct({...editingProduct, name: e.target.value})} /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="text-[9px] font-black text-slate-400 uppercase block mb-1">Custo (R$)</label><input type="number" step="0.01" required className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-black outline-none" value={editingProduct.costPrice} onChange={e => setEditingProduct({...editingProduct, costPrice: Number(e.target.value)})} /></div>
                <div><label className="text-[9px] font-black text-slate-400 uppercase block mb-1">Venda (R$)</label><input type="number" step="0.01" required className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-black text-[#B91C1C] outline-none" value={editingProduct.salePrice} onChange={e => setEditingProduct({...editingProduct, salePrice: Number(e.target.value)})} /></div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div><label className="text-[9px] font-black text-slate-400 uppercase block mb-1">Saldo</label><input type="number" required className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold outline-none" value={editingProduct.currentStock} onChange={e => setEditingProduct({...editingProduct, currentStock: Number(e.target.value)})} /></div>
                <div><label className="text-[9px] font-black text-slate-400 uppercase block mb-1">Mínimo</label><input type="number" required className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold outline-none" value={editingProduct.minStock} onChange={e => setEditingProduct({...editingProduct, minStock: Number(e.target.value)})} /></div>
                <div><label className="text-[9px] font-black text-slate-400 uppercase block mb-1">Unid.</label><select className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold outline-none" value={editingProduct.unit} onChange={e => setEditingProduct({...editingProduct, unit: e.target.value})}><option value="un">un</option><option value="conj">conj</option><option value="par">par</option></select></div>
              </div>
            </div>
            <div className="p-6 md:p-10 border-t border-slate-50 flex gap-4 bg-slate-50/50">
              <button type="button" onClick={() => setShowModal(false)} className="flex-1 py-4 text-slate-400 font-black uppercase text-[10px]">Cancelar</button>
              <button type="submit" className="flex-1 py-4 bg-black text-[#D4AF37] rounded-2xl font-black uppercase text-[10px] tracking-widest">Salvar no Acervo</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default InventoryTable;
