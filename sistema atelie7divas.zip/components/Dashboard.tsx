
import React, { useMemo, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Product, Transaction, RawMaterialEntry, Store, UserRole, User } from '../types';

interface DashboardProps {
  products: Product[];
  transactions: Transaction[];
  rawMaterials: RawMaterialEntry[];
  stores: Store[];
  currentUser: User;
}

const Dashboard: React.FC<DashboardProps> = ({ products, transactions, rawMaterials, stores, currentUser }) => {
  const [isExporting, setIsExporting] = useState(false);

  const stats = useMemo(() => {
    const sales = transactions.filter(t => t.type === 'SALE');
    const totalRevenue = sales.reduce((sum, t) => sum + t.totalValue, 0);
    
    const totalCPV = sales.reduce((sum, t) => {
      const prod = products.find(p => p.id === t.productId);
      return sum + (t.quantity * (prod?.costPrice || 0));
    }, 0);

    const totalRawCosts = rawMaterials.reduce((sum, rm) => sum + (rm.value || 0), 0);
    const netProfit = totalRevenue - totalCPV - totalRawCosts;
    const criticalItems = products.filter(p => p.currentStock <= p.minStock).length;

    return { totalRevenue, netProfit, totalRawCosts, criticalItems };
  }, [transactions, products, rawMaterials]);

  const handleExportToSheet = () => {
    setIsExporting(true);
    const today = new Date().toISOString().split('T')[0];
    
    const dailySales = transactions.filter(t => t.timestamp.startsWith(today) && t.type === 'SALE');
    const dailyInsumos = rawMaterials.filter(rm => rm.date === today);

    const reportData = {
      date: today,
      summary: stats,
      sales: dailySales.map(t => ({
        id: t.id,
        hora: new Date(t.timestamp).toLocaleTimeString(),
        produto: products.find(p => p.id === t.productId)?.name || 'N/A',
        sku: products.find(p => p.id === t.productId)?.sku || 'N/A',
        qtd: t.quantity,
        total: t.totalValue,
        loja: stores.find(s => s.id === t.storeId)?.name || 'N/A'
      })),
      insumos: dailyInsumos,
      inventory: products.map(p => ({ sku: p.sku, nome: p.name, saldo: p.currentStock }))
    };

    setTimeout(() => {
      generateCSVDownload(reportData);
      setIsExporting(false);
    }, 1000);
  };

  const generateCSVDownload = (data: any) => {
    let csvContent = "\ufeff"; 
    csvContent += `RELATORIO DIARIO ATELIE 7 DIVAS - DATA: ${data.date}\n\n`;
    csvContent += "RESUMO FINANCEIRO DO DIA\n";
    csvContent += "Faturamento Total;Lucro Estimado;Custos Insumos;Itens Criticos\n";
    csvContent += `${data.summary.totalRevenue};${data.summary.netProfit};${data.summary.totalRawCosts};${data.summary.criticalItems}\n\n`;
    csvContent += "DETALHAMENTO DE VENDAS / SAIDAS\n";
    csvContent += "ID;HORA;PRODUTO;SKU;QTD;VALOR TOTAL;LOJA\n";
    data.sales.forEach((s: any) => {
      csvContent += `${s.id};${s.hora};${s.produto};${s.sku};${s.qtd};${s.total};${s.loja}\n`;
    });
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Relatorio_7Divas_${data.date}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const chartData = useMemo(() => {
    return products.map(p => ({
      name: p.name.length > 10 ? p.name.substring(0, 8) + '...' : p.name,
      vendas: transactions.filter(t => t.productId === p.id && t.type === 'SALE').reduce((s, t) => s + t.quantity, 0)
    })).sort((a, b) => b.vendas - a.vendas).slice(0, 5);
  }, [products, transactions]);

  const canExport = [UserRole.ADMIN, UserRole.FINANCEIRO, UserRole.GERENCIA].includes(currentUser.role);

  return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in duration-700 w-full overflow-x-hidden">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] shadow-sm border border-slate-100">
        <div className="w-full">
          <h2 className="text-xl md:text-2xl font-black text-slate-900 uppercase tracking-tighter">Performance</h2>
          <p className="text-slate-400 text-[9px] font-bold uppercase tracking-widest">Contabilidade e Gestão</p>
        </div>
        {canExport && (
          <button 
            onClick={handleExportToSheet}
            disabled={isExporting}
            className={`w-full md:w-auto flex items-center justify-center gap-3 px-6 md:px-8 py-3 md:py-4 rounded-xl md:rounded-2xl font-black uppercase text-[9px] tracking-[0.1em] transition-all shadow-xl ${
              isExporting 
              ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
              : 'bg-black text-[#D4AF37] hover:scale-105 active:scale-95'
            }`}
          >
            {isExporting ? 'Processando...' : 'Extrair Planilha'}
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <div className="bg-white p-6 rounded-[1.5rem] shadow-lg border-t-4 border-[#B91C1C]">
          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">Faturamento</p>
          <p className="text-xl md:text-2xl font-black text-slate-900">R$ {stats.totalRevenue.toLocaleString()}</p>
        </div>

        <div className="bg-white p-6 rounded-[1.5rem] shadow-lg border-t-4 border-[#D4AF37]">
          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">Lucro Estimado</p>
          <p className={`text-xl md:text-2xl font-black ${stats.netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            R$ {stats.netProfit.toLocaleString()}
          </p>
        </div>

        <div className="bg-white p-6 rounded-[1.5rem] shadow-lg border-t-4 border-black">
          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">Investimento</p>
          <p className="text-xl md:text-2xl font-black text-slate-900">R$ {stats.totalRawCosts.toLocaleString()}</p>
        </div>

        <div className="bg-black p-6 rounded-[1.5rem] shadow-lg border-t-4 border-[#B91C1C] text-white">
          <p className="text-[9px] font-bold text-[#D4AF37] uppercase tracking-widest mb-1">Esq. Crítico</p>
          <p className="text-2xl md:text-3xl font-black">{stats.criticalItems}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
        <div className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[3rem] shadow-sm border border-slate-100">
          <h3 className="text-lg md:text-xl font-black text-slate-900 mb-6 uppercase tracking-tighter">Volume de Vendas</h3>
          <div className="h-[250px] md:h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 8, fontWeight: 'bold', fill: '#94a3b8'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 8, fontWeight: 'bold', fill: '#94a3b8'}} />
                <Tooltip cursor={{fill: '#f8fafc'}} />
                <Bar dataKey="vendas" radius={[4, 4, 0, 0]} barSize={25}>
                  {chartData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={index === 0 ? '#B91C1C' : '#D4AF37'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 md:p-10 rounded-[2rem] md:rounded-[3rem] shadow-sm border border-slate-100 overflow-hidden">
          <h3 className="text-lg md:text-xl font-black text-slate-900 mb-6 uppercase tracking-tighter">Últimas Saídas</h3>
          <div className="space-y-3">
            {transactions.slice(-4).reverse().map(t => (
              <div key={t.id} className="flex items-center justify-between p-3 md:p-4 bg-slate-50 rounded-xl border border-slate-100">
                <div className="flex items-center gap-3">
                  <div className={`w-1 h-8 rounded-full ${t.type === 'SALE' ? 'bg-green-500' : 'bg-blue-500'}`}></div>
                  <div className="max-w-[120px] md:max-w-none">
                    <p className="text-[9px] font-black text-slate-900 uppercase truncate">
                      {products.find(p => p.id === t.productId)?.name || 'Outro'}
                    </p>
                    <p className="text-[7px] text-slate-400 font-bold">{new Date(t.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                  </div>
                </div>
                <p className="text-[10px] md:text-xs font-black text-slate-900">R$ {t.totalValue.toFixed(0)}</p>
              </div>
            ))}
            {transactions.length === 0 && <p className="text-slate-400 text-center py-12 italic text-xs">Sem dados ainda.</p>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
