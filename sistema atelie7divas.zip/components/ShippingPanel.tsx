
import React, { useState, useMemo } from 'react';
import { Product, Store, Transaction } from '../types';

interface ShippingPanelProps {
  products: Product[];
  stores: Store[];
  transactions: Transaction[];
  onRegisterSale: (productId: string, quantity: number, storeId: string) => boolean;
}

const ShippingPanel: React.FC<ShippingPanelProps> = ({ products, stores, transactions, onRegisterSale }) => {
  const [selectedProduct, setSelectedProduct] = useState('');
  const [selectedStore, setSelectedStore] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');

  // Histórico Permanente: Não filtra por hoje, mostra tudo que foi expedido
  const allExits = useMemo(() => {
    return transactions
      .filter(t => t.type === 'SALE' || t.type === 'EXIT')
      .filter(t => {
        const prodName = products.find(p => p.id === t.productId)?.name.toLowerCase() || '';
        return prodName.includes(searchTerm.toLowerCase()) || t.id.includes(searchTerm.toLowerCase());
      })
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [transactions, products, searchTerm]);

  const handleSale = () => {
    if (!selectedProduct || !selectedStore) return alert("Erro: Selecione a peça e a loja de origem.");
    if (quantity <= 0) return alert("Erro: A quantidade deve ser maior que zero.");
    
    const success = onRegisterSale(selectedProduct, quantity, selectedStore);
    if (success) {
      alert("✅ Saída Registrada com Sucesso!\nEste registro foi enviado para o histórico permanente de auditoria.");
      setSelectedProduct('');
      setQuantity(1);
    }
  };

  return (
    <div className="space-y-10 animate-in slide-in-from-bottom-4 duration-500">
      {/* FORMULÁRIO DE REGISTRO */}
      <div className="bg-white p-12 rounded-[3rem] shadow-xl border border-slate-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8">
          <span className="flex items-center gap-2 text-[8px] font-black text-slate-300 uppercase tracking-[0.3em] bg-slate-50 px-4 py-2 rounded-full border border-slate-100">
            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
            Sistema de Auditoria Ativo
          </span>
        </div>

        <div className="mb-10">
          <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tighter">Registrar Saída / Expedição</h2>
          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-1">Atenção: Registros gerados aqui não podem ser apagados manualmente.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-end">
          <div>
            <label className="text-[10px] font-black text-slate-400 uppercase block mb-3 tracking-widest">Selecione a Peça no Acervo</label>
            <select 
              className="w-full p-5 bg-slate-50 border border-slate-100 rounded-2xl font-bold focus:ring-4 focus:ring-[#B91C1C]/5 outline-none transition-all appearance-none cursor-pointer"
              value={selectedProduct}
              onChange={e => setSelectedProduct(e.target.value)}
            >
              <option value="">Buscar produto...</option>
              {products.map(p => (
                <option key={p.id} value={p.id}>{p.name} (SKU: {p.sku}) | Saldo: {p.currentStock}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[10px] font-black text-slate-400 uppercase block mb-3 tracking-widest">Loja / Destino de Saída</label>
            <select 
              className="w-full p-5 bg-slate-50 border border-slate-100 rounded-2xl font-bold focus:ring-4 focus:ring-[#B91C1C]/5 outline-none transition-all appearance-none cursor-pointer"
              value={selectedStore}
              onChange={e => setSelectedStore(e.target.value)}
            >
              <option value="">Selecione a unidade...</option>
              {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>

          <div className="flex gap-4">
            <div className="w-32">
              <label className="text-[10px] font-black text-slate-400 uppercase block mb-3 tracking-widest">Qtd</label>
              <input 
                type="number" min="1" 
                className="w-full p-5 bg-slate-50 border border-slate-100 rounded-2xl font-black text-center focus:ring-4 focus:ring-[#B91C1C]/5 outline-none"
                value={quantity}
                onChange={e => setQuantity(Number(e.target.value))}
              />
            </div>
            <button 
              onClick={handleSale}
              className="flex-1 bg-black text-[#D4AF37] px-8 py-5 rounded-2xl font-black uppercase text-[10px] tracking-[0.2em] hover:scale-105 active:scale-95 transition-all shadow-2xl shadow-black/20"
            >
              Confirmar Expedição
            </button>
          </div>
        </div>
      </div>

      {/* HISTÓRICO PERMANENTE */}
      <div className="bg-white rounded-[3.5rem] shadow-2xl border border-slate-100 overflow-hidden">
        <div className="p-10 border-b border-slate-50 flex flex-col md:flex-row justify-between items-center gap-6">
          <div>
            <h3 className="text-xl font-black text-slate-900 uppercase tracking-tighter">Livro de Registro de Expedição</h3>
            <p className="text-[9px] text-slate-400 font-bold uppercase mt-1 tracking-widest">Histórico perpétuo de todas as movimentações de saída</p>
          </div>
          <div className="relative w-full md:w-72">
            <input 
              type="text"
              placeholder="Filtrar por produto ou ID..."
              className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-[10px] font-bold outline-none focus:ring-2 focus:ring-black/5"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
            <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          </div>
        </div>

        <div className="overflow-x-auto max-h-[600px] overflow-y-auto custom-scrollbar">
          <table className="w-full text-left">
            <thead className="sticky top-0 bg-slate-50 z-10 text-[9px] font-black text-slate-400 uppercase tracking-[0.3em] border-b border-slate-100">
              <tr>
                <th className="px-10 py-5">Data & Hora Exata</th>
                <th className="px-10 py-5">Identificador (ID)</th>
                <th className="px-10 py-5">Produto Expedido</th>
                <th className="px-10 py-5 text-center">Quantidade</th>
                <th className="px-10 py-5">Unidade de Origem</th>
                <th className="px-10 py-5">Status Auditoria</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {allExits.map(t => (
                <tr key={t.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-10 py-6">
                    <div className="flex flex-col">
                      <span className="text-xs font-black text-slate-900">
                        {new Date(t.timestamp).toLocaleDateString('pt-BR')}
                      </span>
                      <span className="text-[10px] font-bold text-[#B91C1C]">
                        {new Date(t.timestamp).toLocaleTimeString('pt-BR')}
                      </span>
                    </div>
                  </td>
                  <td className="px-10 py-6">
                    <span className="text-[9px] font-mono text-slate-300 font-bold">#{t.id}</span>
                  </td>
                  <td className="px-10 py-6">
                    <p className="font-black text-slate-900 uppercase text-xs">
                      {products.find(p => p.id === t.productId)?.name || 'Peça Removida do Cadastro'}
                    </p>
                    <p className="text-[8px] text-slate-400 font-bold uppercase tracking-tighter">
                      SKU: {products.find(p => p.id === t.productId)?.sku || '---'}
                    </p>
                  </td>
                  <td className="px-10 py-6 text-center">
                    <span className="bg-black text-white px-3 py-1 rounded-lg font-black text-xs">
                      {t.quantity}
                    </span>
                  </td>
                  <td className="px-10 py-6">
                    <span className="text-[10px] font-bold text-slate-500 uppercase">
                      {stores.find(s => s.id === t.storeId)?.name || 'Matriz Jardins'}
                    </span>
                  </td>
                  <td className="px-10 py-6">
                    <div className="flex items-center gap-2">
                       <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                       <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Processado</span>
                    </div>
                  </td>
                </tr>
              ))}
              {allExits.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-32 text-center">
                    <svg className="w-16 h-16 text-slate-100 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <p className="text-slate-300 font-black uppercase tracking-widest text-[10px]">Aguardando registros de expedição.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ShippingPanel;
