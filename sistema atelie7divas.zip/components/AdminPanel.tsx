
import React, { useState, useRef } from 'react';
import { User, Store, UserRole, AppConfig } from '../types';

interface AdminPanelProps {
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  stores: Store[];
  setStores: React.Dispatch<React.SetStateAction<Store[]>>;
  currentUser: User;
  config: AppConfig;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ users, setUsers, stores, setStores, currentUser, config, setConfig }) => {
  const [activeTab, setActiveTab] = useState<'users' | 'stores' | 'branding'>('users');
  const [showStoreModal, setShowStoreModal] = useState(false);
  const [newStoreName, setNewStoreName] = useState('');
  const [editStoreId, setEditStoreId] = useState<string | null>(null);
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<Partial<User> | null>(null);

  const userFileInputRef = useRef<HTMLInputElement>(null);
  const logoFileInputRef = useRef<HTMLInputElement>(null);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const handleUserPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && editingUser) {
      const base64 = await fileToBase64(file);
      setEditingUser({ ...editingUser, avatar: base64 });
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const base64 = await fileToBase64(file);
      setConfig({ ...config, logoUrl: base64 });
    }
  };

  const handleSaveStore = () => {
    if (!newStoreName) return;
    if (editStoreId) {
      setStores(prev => prev.map(s => s.id === editStoreId ? { ...s, name: newStoreName } : s));
    } else {
      setStores(prev => [...prev, { id: `s${Date.now()}`, name: newStoreName, status: 'ATIVA' }]);
    }
    setShowStoreModal(false);
    setNewStoreName('');
    setEditStoreId(null);
  };

  const openUserModal = (user?: User) => {
    if (user) {
      setEditingUser({ ...user });
    } else {
      setEditingUser({
        name: '',
        email: '',
        password: '',
        role: UserRole.ESTOQUE_EXPEDICAO,
        status: 'ATIVO',
        avatar: ''
      });
    }
    setShowUserModal(true);
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    if (editingUser.id) {
      setUsers(prev => prev.map(u => u.id === editingUser.id ? (editingUser as User) : u));
    } else {
      const newUser = { ...editingUser, id: `u${Date.now()}` } as User;
      setUsers(prev => [...prev, newUser]);
    }
    setShowUserModal(false);
    setEditingUser(null);
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="flex bg-white p-2 rounded-2xl shadow-sm border border-slate-100 w-fit">
        <button onClick={() => setActiveTab('users')} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'users' ? 'bg-black text-[#D4AF37]' : 'text-slate-400 hover:bg-slate-50'}`}>Equipe</button>
        <button onClick={() => setActiveTab('stores')} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'stores' ? 'bg-black text-[#D4AF37]' : 'text-slate-400 hover:bg-slate-50'}`}>Unidades</button>
        <button onClick={() => setActiveTab('branding')} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'branding' ? 'bg-black text-[#D4AF37]' : 'text-slate-400 hover:bg-slate-50'}`}>Identidade Visual</button>
      </div>

      {activeTab === 'users' && (
        <section className="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-xl font-black text-slate-900 uppercase">Colaboradores & Acessos</h3>
            <button onClick={() => openUserModal()} className="bg-black text-[#D4AF37] px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl">+ Novo Usuário</button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {users.map(u => (
              <div key={u.id} className="p-6 bg-slate-50 rounded-[2.5rem] border border-slate-100 flex items-center justify-between group">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full border-2 border-white shadow-md overflow-hidden bg-black flex items-center justify-center">
                    {u.avatar ? <img src={u.avatar} className="w-full h-full object-cover" /> : <span className="text-[10px] font-bold text-white">{u.name.charAt(0)}</span>}
                  </div>
                  <div>
                    <p className="font-black text-slate-900 text-xs uppercase">{u.name}</p>
                    <p className="text-[8px] text-slate-400 font-bold mb-1">{u.email}</p>
                    <span className="px-2 py-0.5 bg-black text-[#D4AF37] text-[7px] font-black rounded-full uppercase">{u.role}</span>
                  </div>
                </div>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => openUserModal(u)} className="p-2 text-slate-400 hover:text-black"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" strokeWidth={2} /></svg></button>
                  {u.id !== currentUser.id && <button onClick={() => confirm("Remover?") && setUsers(prev => prev.filter(x => x.id !== u.id))} className="p-2 text-slate-400 hover:text-red-600"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" strokeWidth={2} /></svg></button>}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {activeTab === 'stores' && (
        <section className="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-xl font-black text-slate-900 uppercase tracking-tighter">Gerenciamento de Unidades</h3>
            <button onClick={() => { setShowStoreModal(true); setEditStoreId(null); setNewStoreName(''); }} className="bg-[#B91C1C] text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl">+ Nova Unidade</button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {stores.map(s => (
              <div key={s.id} className="p-6 bg-black rounded-[2rem] border border-[#D4AF37]/30 flex justify-between items-center">
                <div>
                  <p className="text-[#D4AF37] font-black uppercase text-sm">{s.name}</p>
                  <p className="text-[8px] text-slate-500 font-bold uppercase mt-1">Status: {s.status}</p>
                </div>
                <button onClick={() => { setEditStoreId(s.id); setNewStoreName(s.name); setShowStoreModal(true); }} className="text-white hover:text-[#D4AF37] p-2"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" strokeWidth={2} /></svg></button>
              </div>
            ))}
          </div>
        </section>
      )}

      {activeTab === 'branding' && (
        <section className="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100 max-w-2xl">
          <h3 className="text-xl font-black text-slate-900 uppercase mb-8 tracking-tighter">Personalização do Sistema</h3>
          <div className="space-y-6">
            <div>
              <label className="text-[10px] font-black text-slate-400 uppercase block mb-2 tracking-widest">Nome do Sistema (Exibido na Sidebar/Login)</label>
              <input className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none" value={config.companyName} onChange={e => setConfig({...config, companyName: e.target.value})} />
            </div>
            
            <div className="p-8 border-2 border-dashed border-slate-100 rounded-[2rem] bg-slate-50/50 flex flex-col items-center">
               <label className="text-[10px] font-black text-slate-400 uppercase block mb-4 tracking-widest">Logotipo da Empresa</label>
               <div className="w-32 h-32 bg-white rounded-3xl shadow-lg border border-slate-100 mb-6 flex items-center justify-center overflow-hidden">
                 {config.logoUrl ? <img src={config.logoUrl} className="w-full h-full object-contain" /> : <span className="text-3xl font-black text-slate-200">{config.logoText}</span>}
               </div>
               <input type="file" ref={logoFileInputRef} onChange={handleLogoUpload} accept="image/*" className="hidden" />
               <button 
                  onClick={() => logoFileInputRef.current?.click()}
                  className="bg-black text-[#D4AF37] px-6 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest hover:scale-105 transition-all shadow-xl shadow-black/10"
                >
                 Escolher Arquivo de Logo
               </button>
               <p className="text-[8px] text-slate-400 mt-3 font-bold uppercase tracking-tighter">Formatos: JPG, PNG, WEBP (Quadrado recomendado)</p>
            </div>

            <div className="p-6 bg-black rounded-[2rem] border border-[#D4AF37]/20">
               <p className="text-[10px] font-black text-[#D4AF37] uppercase mb-4 tracking-widest">Resumo de Identidade</p>
               <div className="flex items-center gap-6">
                 {config.logoUrl ? <img src={config.logoUrl} className="w-20 h-20 object-contain rounded-xl" /> : <div className="w-16 h-16 bg-[#D4AF37] rounded-full flex items-center justify-center font-black">{config.logoText}</div>}
                 <div>
                    <h4 className="font-black text-white uppercase text-lg">{config.companyName}</h4>
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Branding Ativo</p>
                 </div>
               </div>
            </div>
          </div>
        </section>
      )}

      {/* MODAL DE USUÁRIOS */}
      {showUserModal && editingUser && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[110] flex items-center justify-center p-6">
          <form onSubmit={handleSaveUser} className="bg-white w-full max-w-lg rounded-[3rem] overflow-hidden shadow-2xl">
            <div className="bg-black p-10 text-center">
              <h2 className="text-[#D4AF37] font-black uppercase tracking-[0.2em] text-xl">Acesso Corporativo</h2>
            </div>
            <div className="p-10 space-y-4">
              <div className="flex flex-col items-center gap-4 mb-6 p-6 bg-slate-50 rounded-[2rem] border border-slate-100">
                <div className="w-24 h-24 rounded-full border-4 border-white shadow-xl overflow-hidden bg-black flex items-center justify-center">
                  {editingUser.avatar ? <img src={editingUser.avatar} className="w-full h-full object-cover" /> : <span className="text-2xl font-black text-white">{editingUser.name?.charAt(0) || '?'}</span>}
                </div>
                <input type="file" ref={userFileInputRef} onChange={handleUserPhotoUpload} accept="image/*" className="hidden" />
                <button 
                  type="button"
                  onClick={() => userFileInputRef.current?.click()}
                  className="bg-black text-[#D4AF37] px-4 py-2 rounded-lg text-[8px] font-black uppercase tracking-widest"
                >
                  Carregar Foto do Colaborador
                </button>
              </div>
              
              <div><label className="text-[10px] font-black text-slate-400 uppercase block mb-2 tracking-widest">Nome Completo</label><input required className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold" value={editingUser.name} onChange={e => setEditingUser({...editingUser, name: e.target.value})} /></div>
              <div><label className="text-[10px] font-black text-slate-400 uppercase block mb-2 tracking-widest">E-mail</label><input required type="email" className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold" value={editingUser.email} onChange={e => setEditingUser({...editingUser, email: e.target.value})} /></div>
              <div><label className="text-[10px] font-black text-slate-400 uppercase block mb-2 tracking-widest">Senha</label><input required type="password" title="Senha de acesso" className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold" value={editingUser.password} onChange={e => setEditingUser({...editingUser, password: e.target.value})} /></div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase block mb-2 tracking-widest">Cargo</label>
                <select className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none" value={editingUser.role} onChange={e => setEditingUser({...editingUser, role: e.target.value as UserRole})}>
                  {Object.values(UserRole).map(role => <option key={role} value={role}>{role}</option>)}
                </select>
              </div>
              <div className="flex gap-4 pt-6">
                <button type="button" onClick={() => setShowUserModal(false)} className="flex-1 py-4 text-slate-400 font-black uppercase text-[10px] tracking-widest">Cancelar</button>
                <button type="submit" className="flex-1 py-4 bg-black text-[#D4AF37] rounded-2xl font-black uppercase text-[10px] tracking-widest">Salvar</button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* MODAL DE LOJAS */}
      {showStoreModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[110] flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-md rounded-[3rem] p-10 shadow-2xl">
            <h2 className="text-xl font-black text-slate-900 uppercase mb-6">{editStoreId ? 'Editar Loja' : 'Nova Loja'}</h2>
            <input autoFocus className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold mb-6 outline-none" value={newStoreName} onChange={e => setNewStoreName(e.target.value)} placeholder="Nome da Loja" />
            <div className="flex gap-4">
              <button onClick={() => setShowStoreModal(false)} className="flex-1 py-4 text-slate-400 font-black uppercase text-[10px]">Cancelar</button>
              <button onClick={handleSaveStore} className="flex-1 py-4 bg-[#B91C1C] text-white rounded-2xl font-black uppercase text-[10px]">Salvar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
