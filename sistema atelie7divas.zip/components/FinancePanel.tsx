
import React, { useState } from 'react';
import { RawMaterialEntry, User, UserRole } from '../types';

interface FinancePanelProps {
  rawMaterials: RawMaterialEntry[];
  onAddRawMaterial: (rm: Omit<RawMaterialEntry, 'id'>) => void;
  onUpdateRawMaterial: (rm: RawMaterialEntry) => void;
  onDeleteRawMaterial: (id: string) => void;
  currentUser: User;
}

const FinancePanel: React.FC<FinancePanelProps> = ({ 
  rawMaterials, 
  onAddRawMaterial, 
  onUpdateRawMaterial,
  onDeleteRawMaterial,
  currentUser 
}) => {
  const [showModal, setShowModal] = useState(false);
  const [editingEntry, setEditingEntry] = useState<RawMaterialEntry | null>(null);
  const [form, setForm] = useState({ 
    item: '', 
    quantity: 0, 
    value: 0, 
    supplier: '', 
    unit: 'metros',
    date: new Date().toISOString().split('T')[0]
  });

  const isEntryOnly = currentUser.role === UserRole.ENTRADA_INSUMOS;
  const isAdmin = currentUser.role === UserRole.ADMIN;

  const handleOpenAdd = () => {
    setEditingEntry(null);
    setForm({ 
      item: '', 
      quantity: 0, 
      value: 0, 
      supplier: '', 
      unit: 'metros',
      date: new Date().toISOString().split('T')[0]
    });
    setShowModal(true);
  };

  const handleOpenEdit = (rm: RawMaterialEntry) => {
    setEditingEntry(rm);
    setForm({ 
      item: rm.item, 
      quantity: rm.quantity, 
      value: rm.value || 0, 
      supplier: rm.supplier, 
      unit: rm.unit || 'metros',
      date: rm.date
    });
    setShowModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingEntry) {
      onUpdateRawMaterial({
        ...editingEntry,
        ...form
      });
    } else {
      onAddRawMaterial({
        ...form,
        userId: currentUser.id
      });
    }
    setShowModal(false);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
        <div className="flex justify-between items-center mb-10">
          <div>
            <h3 className="text-xl font-black text-slate-900 uppercase tracking-tighter">
              {isEntryOnly ? 'Recebimento de Insumos (Tecidos)' : 'Custos de Produção & Matéria-Prima'}
            </h3>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">
              {isEntryOnly 
                ? 'Controle de entrada física e auditoria de metragem.' 
                : 'Gestão de valores para cálculo de lucratividade real.'}
            </p>
          </div>
          <button 
            onClick={handleOpenAdd}
            className="bg-[#B91C1C] text-white px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-[#B91C1C]/20 hover:scale-105 active:scale-95 transition-all"
          >
            + Registrar Entrada
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-100">
              <tr>
                <th className="pb-6 px-4">Data</th>
                <th className="pb-6 px-4">Insumo / Tecido</th>
                <th className="pb-6 px-4">Fornecedor</th>
                <th className="pb-6 px-4 text-right">Qtd</th>
                <th className="pb-6 px-4 text-right">Unidade</th>
                {!isEntryOnly && <th className="pb-6 px-4 text-right">Valor Total</th>}
                <th className="pb-6 px-4 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {[...rawMaterials].sort((a,b) => b.date.localeCompare(a.date)).map(rm => (
                <tr key={rm.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="py-6 px-4 text-[10px] text-slate-400 font-black uppercase tracking-tighter">
                    {new Date(rm.date + 'T12:00:00').toLocaleDateString('pt-BR')}
                  </td>
                  <td className="py-6 px-4">
                    <p className="font-black text-slate-900 uppercase text-xs">{rm.item}</p>
                  </td>
                  <td className="py-6 px-4 text-slate-500 font-bold italic text-xs">{rm.supplier}</td>
                  <td className="py-6 px-4 text-right">
                    <span className="bg-slate-100 px-3 py-1 rounded-lg font-black text-xs text-slate-700">
                      {rm.quantity}
                    </span>
                  </td>
                  <td className="py-6 px-4 text-right font-bold text-slate-400 uppercase text-[9px] tracking-widest">{rm.unit || 'un'}</td>
                  {!isEntryOnly && (
                    <td className="py-6 px-4 text-right font-black text-[#B91C1C]">
                      R$ {rm.value?.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </td>
                  )}
                  <td className="py-6 px-4">
                    <div className="flex justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => handleOpenEdit(rm)}
                        className="p-2 text-slate-300 hover:text-blue-600 transition-colors"
                        title="Editar Registro"
                      >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                      </button>
                      {isAdmin && (
                        <button 
                          onClick={() => confirm('Excluir este insumo permanentemente?') && onDeleteRawMaterial(rm.id)}
                          className="p-2 text-slate-300 hover:text-red-600 transition-colors"
                          title="Remover Registro"
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {rawMaterials.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-32 text-center text-slate-300 font-bold uppercase text-[10px] tracking-widest">Aguardando primeiros registros de insumos.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
          <form onSubmit={handleSubmit} className="bg-white w-full max-w-lg rounded-[3rem] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="bg-black p-10 text-center">
              <h2 className="text-[#D4AF37] font-black uppercase tracking-[0.2em] text-xl">
                {editingEntry ? 'Corrigir Lançamento' : 'Nova Entrada de Insumo'}
              </h2>
            </div>
            <div className="p-10 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2 md:col-span-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase block mb-2 tracking-widest">Data do Recebimento</label>
                  <input 
                    type="date" 
                    required 
                    className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none focus:ring-4 focus:ring-[#B91C1C]/5" 
                    value={form.date} 
                    onChange={e => setForm({...form, date: e.target.value})} 
                  />
                </div>
                <div className="col-span-2 md:col-span-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase block mb-2 tracking-widest">Unidade de Medida</label>
                  <select 
                    className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none focus:ring-4 focus:ring-[#B91C1C]/5"
                    value={form.unit}
                    onChange={e => setForm({...form, unit: e.target.value})}
                  >
                    <option value="metros">Metros</option>
                    <option value="un">Unidades</option>
                    <option value="rolos">Rolos</option>
                    <option value="kg">Quilos</option>
                    <option value="conj">Conjuntos</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase block mb-2 tracking-widest">Descrição do Item / Tecido</label>
                <input required className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none focus:ring-4 focus:ring-[#B91C1C]/5" value={form.item} onChange={e => setForm({...form, item: e.target.value})} placeholder="Ex: Tecido Seda Italiana 100%" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase block mb-2 tracking-widest">Quantidade</label>
                  <input type="number" step="0.01" required className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl font-black outline-none focus:ring-4 focus:ring-[#B91C1C]/5" value={form.quantity} onChange={e => setForm({...form, quantity: Number(e.target.value)})} />
                </div>
                {!isEntryOnly && (
                  <div>
                    <label className="text-[10px] font-black text-slate-400 uppercase block mb-2 tracking-widest">Valor Total (R$)</label>
                    <input type="number" step="0.01" required className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl text-[#B91C1C] font-black outline-none focus:ring-4 focus:ring-[#B91C1C]/5" value={form.value} onChange={e => setForm({...form, value: Number(e.target.value)})} />
                  </div>
                )}
              </div>

              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase block mb-2 tracking-widest">Fornecedor</label>
                <input required className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold outline-none focus:ring-4 focus:ring-[#B91C1C]/5" value={form.supplier} onChange={e => setForm({...form, supplier: e.target.value})} placeholder="Ex: Têxtil Luxo Import" />
              </div>

              <div className="flex gap-4 pt-6">
                <button type="button" onClick={() => setShowModal(false)} className="flex-1 py-4 text-slate-400 font-black uppercase text-[10px] tracking-widest hover:text-slate-600 transition-colors">Cancelar</button>
                <button type="submit" className="flex-1 py-4 bg-black text-[#D4AF37] rounded-2xl font-black uppercase text-[10px] tracking-[0.2em] shadow-xl shadow-black/10 hover:scale-[1.02] active:scale-95 transition-all">
                  {editingEntry ? 'Salvar Correção' : 'Confirmar Lançamento'}
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default FinancePanel;
