
import React, { useState, useMemo } from 'react';
import { Store, Transaction, Product } from '../types';

interface StoreAnalyticsProps {
  stores: Store[];
  transactions: Transaction[];
  products: Product[];
}

const StoreAnalytics: React.FC<StoreAnalyticsProps> = ({ stores, transactions, products }) => {
  const [selectedStoreId, setSelectedStoreId] = useState<string>(stores[0]?.id || '');
  const [days, setDays] = useState<1 | 15 | 30>(30);

  const stats = useMemo(() => {
    const now = new Date();
    const startDate = new Date();
    startDate.setDate(now.getDate() - days);

    const storeTx = transactions.filter(t => 
      t.storeId === selectedStoreId && 
      t.type === 'SALE' && 
      new Date(t.timestamp) >= startDate
    );

    const totalQty = storeTx.reduce((sum, t) => sum + t.quantity, 0);
    const totalRev = storeTx.reduce((sum, t) => sum + t.totalValue, 0);
    
    // Top produto da loja no periodo
    const prodCounts: Record<string, number> = {};
    storeTx.forEach(t => {
      if (t.productId) prodCounts[t.productId] = (prodCounts[t.productId] || 0) + t.quantity;
    });
    
    const topProdId = Object.keys(prodCounts).sort((a, b) => prodCounts[b] - prodCounts[a])[0];
    const topProd = products.find(p => p.id === topProdId);

    return { totalQty, totalRev, topProd, storeTx };
  }, [selectedStoreId, days, transactions, products]);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row gap-6 items-center justify-between bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
        <div className="flex gap-4">
          {stores.map(s => (
            <button
              key={s.id}
              onClick={() => setSelectedStoreId(s.id)}
              className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${
                selectedStoreId === s.id ? 'bg-[#B91C1C] text-white' : 'bg-slate-50 text-slate-400'
              }`}
            >
              {s.name}
            </button>
          ))}
        </div>
        <div className="flex bg-slate-100 p-1 rounded-xl">
          {[1, 15, 30].map(d => (
            <button
              key={d}
              onClick={() => setDays(d as any)}
              className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase transition-all ${
                days === d ? 'bg-white shadow-sm text-slate-900' : 'text-slate-400'
              }`}
            >
              {d === 1 ? 'Hoje' : `${d} Dias`}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-10 rounded-[3rem] shadow-xl border-t-8 border-black">
          <p className="text-[10px] font-black text-slate-400 uppercase mb-2">Volume de Vendas</p>
          <p className="text-4xl font-black text-slate-900">{stats.totalQty} <span className="text-sm">peças</span></p>
        </div>
        <div className="bg-white p-10 rounded-[3rem] shadow-xl border-t-8 border-[#B91C1C]">
          <p className="text-[10px] font-black text-slate-400 uppercase mb-2">Faturamento Unidade</p>
          <p className="text-4xl font-black text-slate-900">R$ {stats.totalRev.toLocaleString()}</p>
        </div>
        <div className="bg-white p-10 rounded-[3rem] shadow-xl border-t-8 border-[#D4AF37]">
          <p className="text-[10px] font-black text-slate-400 uppercase mb-2">Mais Vendido na Loja</p>
          <p className="text-xl font-black text-slate-900 uppercase truncate">
            {stats.topProd?.name || '---'}
          </p>
        </div>
      </div>

      <div className="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100 overflow-hidden">
        <h3 className="text-lg font-black text-slate-900 uppercase mb-6">Detalhamento de Saídas - Período de {days} dias</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="text-[9px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-50">
              <tr>
                <th className="pb-4">Data/Hora</th>
                <th className="pb-4">Produto</th>
                <th className="pb-4 text-right">Qtd</th>
                <th className="pb-4 text-right">Valor Venda</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {stats.storeTx.map(t => (
                <tr key={t.id} className="text-sm">
                  <td className="py-4 text-slate-400 font-bold">{new Date(t.timestamp).toLocaleDateString()} {new Date(t.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</td>
                  <td className="py-4 font-black text-slate-900 uppercase">
                    {products.find(p => p.id === t.productId)?.name}
                  </td>
                  <td className="py-4 text-right font-black">{t.quantity}</td>
                  <td className="py-4 text-right font-bold">R$ {t.totalValue.toLocaleString()}</td>
                </tr>
              ))}
              {stats.storeTx.length === 0 && (
                <tr>
                  <td colSpan={4} className="py-20 text-center text-slate-300 font-bold uppercase text-[10px]">Sem movimentações neste período para esta loja.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default StoreAnalytics;
