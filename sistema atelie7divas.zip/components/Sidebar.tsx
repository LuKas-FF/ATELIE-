
import React from 'react';
import { User, UserRole, AppConfig } from '../types';
import { ICONS } from '../constants';

interface SidebarProps {
  user: User;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
  config: AppConfig;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ user, activeTab, setActiveTab, onLogout, config, isOpen, setIsOpen }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard Geral', icon: ICONS.Dashboard, roles: [UserRole.ADMIN, UserRole.GERENCIA, UserRole.FINANCEIRO] },
    { id: 'store_analytics', label: 'Analítico Lojas', icon: ICONS.Audit, roles: [UserRole.ADMIN, UserRole.GERENCIA] },
    { id: 'inventory', label: 'Estoque / Acervo', icon: ICONS.Inventory, roles: [UserRole.ADMIN, UserRole.ESTOQUE_EXPEDICAO] },
    { id: 'shipping', label: 'Expedição', icon: ICONS.Transaction, roles: [UserRole.ADMIN, UserRole.ESTOQUE_EXPEDICAO] },
    { id: 'finance', label: 'Entrada de Insumos', icon: ICONS.Audit, roles: [UserRole.ADMIN, UserRole.FINANCEIRO, UserRole.ENTRADA_INSUMOS] },
    { id: 'admin', label: 'Administrativo', icon: ICONS.Users, roles: [UserRole.ADMIN] },
  ];

  const filteredItems = menuItems.filter(item => item.roles.includes(user.role));

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setIsOpen(false); // Fecha o menu no mobile ao clicar em um item
  };

  return (
    <>
      {/* Overlay para mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40 md:hidden transition-opacity"
          onClick={() => setIsOpen(false)}
        />
      )}

      <aside className={`
        fixed left-0 top-0 h-screen w-64 bg-black shadow-2xl z-50 border-r border-[#D4AF37]/20 
        flex flex-col transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full'} 
        md:translate-x-0
      `}>
        <div className="p-8 border-b border-white/10 flex flex-col items-center relative">
          <button 
            onClick={() => setIsOpen(false)}
            className="absolute right-4 top-4 md:hidden text-slate-500 hover:text-white p-2"
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>

          {config.logoUrl ? (
            <img src={config.logoUrl} alt="Logo" className="w-16 h-16 object-contain rounded-2xl mb-4" />
          ) : (
            <div className="w-14 h-14 rounded-full flex items-center justify-center font-bold text-black border-2 border-white text-xl bg-[#D4AF37]">
              {config.logoText}
            </div>
          )}
          <h1 className="text-[10px] font-black text-white tracking-[0.4em] mt-3 text-center uppercase leading-tight">{config.companyName}</h1>
        </div>

        <nav className="flex-1 p-4 space-y-2 mt-4 overflow-y-auto custom-scrollbar">
          {filteredItems.map(item => (
            <button
              key={item.id}
              onClick={() => handleTabChange(item.id)}
              className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl transition-all duration-300 group ${
                activeTab === item.id 
                ? 'bg-[#B91C1C] text-white shadow-xl shadow-[#B91C1C]/30 scale-[1.02]' 
                : 'text-slate-500 hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon className={`w-5 h-5 ${activeTab === item.id ? 'text-white' : 'group-hover:text-[#D4AF37]'}`} />
              <span className="text-[10px] font-black uppercase tracking-[0.2em]">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-white/10 bg-[#080808]">
          <div className="flex items-center gap-3 mb-6 bg-white/5 p-3 rounded-2xl border border-white/5">
            <img src={user.avatar || 'https://i.pravatar.cc/150'} className="w-10 h-10 rounded-xl border border-[#D4AF37]/30 object-cover" />
            <div className="flex-1 overflow-hidden">
              <p className="text-[10px] font-black text-white truncate uppercase tracking-tighter">{user.name}</p>
              <p className="text-[8px] text-[#D4AF37] uppercase font-bold tracking-widest mt-0.5">{user.role}</p>
            </div>
          </div>
          <button onClick={onLogout} className="w-full flex items-center justify-center gap-2 px-4 py-3 border border-white/10 text-[9px] font-black text-slate-500 hover:text-white hover:bg-red-950/20 hover:border-red-900/30 rounded-xl uppercase tracking-widest transition-all">
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
            Encerrar Sessão
          </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
